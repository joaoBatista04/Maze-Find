
#ifndef _TYPES_H_
#define _TYPES_H_

typedef unsigned char bool;
typedef unsigned char byte;

#endif