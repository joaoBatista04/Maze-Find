
#include <stdio.h>
#include <stdlib.h>

#include "forward_list.h"

// TODO!